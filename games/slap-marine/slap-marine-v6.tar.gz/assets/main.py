import asyncio

# pygbag's WASM pygame does not auto-import these submodules the way desktop
# pygame does, so pg.sprite / pg.mixer / pg.font must be imported explicitly
# before any class (e.g. Player(pg.sprite.Sprite)) is defined.
import pygame
import pygame.sprite
import pygame.mixer
import pygame.font

from scripts.settings import *
from scripts.classes.game_class import Game


# pygbag entry point: the render loop lives in Game.play(), which is async and
# yields to the browser once per frame. The original desktop main.pyw structure
# is preserved otherwise.
async def main():
    while True:
        game = Game()
        await game.play()
        q = game.end_screen()
        if q == "quit":
            break
    pg.quit()


asyncio.run(main())
